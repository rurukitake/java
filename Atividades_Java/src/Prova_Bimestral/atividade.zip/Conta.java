package Prova_Bimestral;

public class Conta {

}
